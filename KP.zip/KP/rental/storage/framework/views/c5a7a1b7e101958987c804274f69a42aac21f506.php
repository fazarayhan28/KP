<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-dark navbar-expand-lg fixed-top bg-dark" id="mainNav">
        <div class="container"><a class="navbar-brand" href="<?php echo e(url ('mobils')); ?>" >NasiBalap Rentcar</a><button data-bs-toggle="collapse" data-bs-target="#navbarResponsive" class="navbar-toggler navbar-toggler-right" type="button" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ms-auto text-uppercase">
                    <li class="nav-item"><a class="nav-link" href="#contact">admin</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <section class="bg-light" id="portfolio">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="text-uppercase section-heading">pENGKINIAN DATA</h2>
                    <h3 class="text-muted section-subheading">Lorem ipsum dolor sit amet consectetur.</h3>
                </div>
            </div>
            <div class="row">
            <?php $__currentLoopData = $mobils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobilan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <div class="col-sm-6 col-md-4 portfolio-item"><a class="portfolio-link" href="<?php echo e(url('mobils/'.$mobilan->id.'/edit')); ?>" data-target=#portfolioModal3>
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content"><i class="fa fa-plus fa-3x"></i></div>
                        </div><img class="img-fluid" src="/assets/img/mobil/<?php echo e($mobilan->gambar); ?>">
                    </a>
                    <div class="portfolio-caption">
                    <form action="<?php echo e(url('mobils/'.$mobilan->id)); ?>" method="POST">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <h4><?php echo e($mobilan->nama); ?></h4><button class="btn btn-primary float-start" type="Submit">Hapus</button><button class="btn btn-primary float-end" type="button">Edit</button>
                        <p class="text-muted"><?php echo e($mobilan->jumlah); ?></p>
                        </form>
                    </div>  
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div><a class="portfolio-link" href="#portfolioModal1" data-bs-toggle="modal"><button class="btn btn-primary float-end d-lg-flex" type="button">+ Tambah Armada</button></a>
        </div>
    </section>
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4"><span class="copyright">Copyright&nbsp;© Brand 2021</span></div>
                <div class="col-md-4">
                    <ul class="list-inline social-buttons">
                        <li class="list-inline-item"><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="list-inline quicklinks">
                        <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
                        <li class="list-inline-item"><a href="#">Terms of Use</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <div class="modal fade text-center portfolio-modal" role="dialog" tabindex="-1" id="portfolioModal3">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                
            </div>
        </div>
    </div>

    <div class="modal fade text-center portfolio-modal" role="dialog" tabindex="-1" id="portfolioModal1">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 mx-auto">
                            <div class="modal-body">
                                <h2 class="text-uppercase">TAMBAH KENDARAAN</h2>
                                <form action="<?php echo e(url('mobils')); ?>" method="POST">
                                    <?php echo csrf_field(); ?> 
                                    
                                <div class="row">
                                    <div class="col align-self-center">
                                        <h6 class="text-start">Nama Kendaraan :</h6>
                                    </div>
                                    <div class="col align-self-center"><input type="text" name="nama"></div>
                                </div>
                                <div class="row">
                                    <div class="col align-self-center">
                                        <h6 class="text-start">Jumlah :</h6>
                                    </div>
                                    <div class="col align-self-center"><input type="number" name="jumlah"></div>
                                </div>
                                <div class="row">
                                    <div class="col d-lg-flex align-self-center">
                                        <h6 class="text-start">Nama File :</h6>
                                    </div>
                                    <div class="col align-self-center"><input type="text" name="gambar"></div>
                                </div><button class="btn btn-primary" type="submit" data-bs-dismiss="modal"><i class="fa fa-plus"></i><span>&nbsp;Tambah</span></button>
</form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade text-center portfolio-modal" role="dialog" tabindex="-1" id="portfolioModal2">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 mx-auto">
                            <div class="modal-body">
                                <h2 class="text-uppercase">HAPUS KENDARAAN?</h2>
                                <a href="<?php echo e(url('mobils/create')); ?>">
                                <button class="btn btn-primary" type="button" data-bs-dismiss="modal" style="margin: 10px;"><i class="fa fa-times"></i><span>&nbsp;TIDAK</span></button></a>
                                <button class="btn btn-primary" type="submit" data-bs-dismiss="modal" style="margin: 10px;"><i class="fa fa-check"></i><span>&nbsp;YA</span></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('mobils.templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fazarayhanova/Documents/aplikasi/KP/rental/resources/views/mobils/create.blade.php ENDPATH**/ ?>