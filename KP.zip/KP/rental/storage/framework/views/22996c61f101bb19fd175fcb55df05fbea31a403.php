<?php $__env->startSection('content'); ?>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 mx-auto">
                            <div class="modal-body">
                                <h2 class="text-uppercase">UPDATE KENDARAAN</h2>
                                <form action="<?php echo e(url('mobils/'.$mobil->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="PATCH"> 
                                    
                                <div class="row">
                                    <div class="col align-self-center">
                                        <h6 class="text-start">Nama Kendaraan :</h6>
                                    </div>
                                    <div class="col align-self-center"><input type="text" name="nama" value="<?php echo e($mobil->nama); ?>"></div>
                                </div>
                                <div class="row">
                                    <div class="col align-self-center">
                                        <h6 class="text-start">Jumlah :</h6>
                                    </div>
                                    <div class="col align-self-center"><input type="number" name="jumlah" value="<?php echo e($mobil->jumlah); ?>"></div>
                                </div>
                                <div class="row">
                                    <div class="col d-lg-flex align-self-center">
                                        <h6 class="text-start">Nama File :</h6>
                                    </div>
                                    <div class="col align-self-center"><input type="text" name="gambar" value="<?php echo e($mobil->gambar); ?>"></div>
                                </div><button class="btn btn-primary" type="submit" data-bs-dismiss="modal"><i class="fa fa-plus"></i><span>&nbsp;Simpan</span></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mobils.templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fazarayhanova/Documents/aplikasi/KP/rental/resources/views/mobils/edit.blade.php ENDPATH**/ ?>